import { StructuralDirectivesDirective } from './structural-directives.directive';

describe('StructuralDirectivesDirective', () => {
  it('should create an instance', () => {
    const directive = new StructuralDirectivesDirective();
    expect(directive).toBeTruthy();
  });
});
