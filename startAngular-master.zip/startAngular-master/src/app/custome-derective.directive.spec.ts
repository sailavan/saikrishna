import { CustomeDerectiveDirective } from './custome-derective.directive';

describe('CustomeDerectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomeDerectiveDirective();
    expect(directive).toBeTruthy();
  });
});
