import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cow',
  templateUrl: './cow.component.html',
  styleUrls: ['./cow.component.css']
})
export class CowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
